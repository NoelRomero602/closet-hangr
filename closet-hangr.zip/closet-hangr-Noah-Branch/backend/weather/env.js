export default {
  OPEN_WEATHER_API_KEY: 'f324d051137ba2c350b49e9be854ecf9'
}
